package tiketbioskop;

//import java.awt.event.KeyEvent;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.sql.Statement;
//import java.util.HashMap;
import javax.swing.JOptionPane;

public class Utama extends javax.swing.JFrame {
    
    Connection con;
    Statement stm;
    ResultSet rs;
    
    public Utama() {
        initComponents();
        koneksi.getKoneksi();  
        fnama.requestFocus();
        bayangan1.setVisible(false);
        bayangan2.setVisible(false);
        bayangan3.setVisible(false);
        bayangan4.setVisible(false);
        bayangan5.setVisible(false);
        
       
        
//      Membuat ID Pelanggan Otomatis
        autoid();
//        Memanggil Nama Pesawat
//        pesawat();
//        Mengambil Tanggal Sekarang
        Date date = new Date();
        tanggal.setDate(date);
//        Memanggil Data Kelas
       // kelas();
      // harga1();
      
    
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField5 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jMenuBar2 = new javax.swing.JMenuBar();
        jMenu3 = new javax.swing.JMenu();
        jMenu4 = new javax.swing.JMenu();
        jMenuBar3 = new javax.swing.JMenuBar();
        jMenu5 = new javax.swing.JMenu();
        jMenu6 = new javax.swing.JMenu();
        jMenuBar4 = new javax.swing.JMenuBar();
        jMenu7 = new javax.swing.JMenu();
        jMenu8 = new javax.swing.JMenu();
        jMenuBar5 = new javax.swing.JMenuBar();
        jMenu9 = new javax.swing.JMenu();
        jMenu10 = new javax.swing.JMenu();
        jMenuBar6 = new javax.swing.JMenuBar();
        jMenu11 = new javax.swing.JMenu();
        jMenu12 = new javax.swing.JMenu();
        jMenuBar7 = new javax.swing.JMenuBar();
        jMenu13 = new javax.swing.JMenu();
        jMenu14 = new javax.swing.JMenu();
        jMenuBar8 = new javax.swing.JMenuBar();
        jMenu15 = new javax.swing.JMenu();
        jMenu16 = new javax.swing.JMenu();
        jMenuBar9 = new javax.swing.JMenuBar();
        jMenu17 = new javax.swing.JMenu();
        jMenu18 = new javax.swing.JMenu();
        jMenuBar10 = new javax.swing.JMenuBar();
        jMenu19 = new javax.swing.JMenu();
        jMenu20 = new javax.swing.JMenu();
        jScrollPane1 = new javax.swing.JScrollPane();
        button1 = new java.awt.Button();
        label1 = new java.awt.Label();
        jPanel3 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        btnsimpan1 = new javax.swing.JButton();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        bayangan5 = new javax.swing.JTextField();
        bayangan1 = new javax.swing.JTextField();
        kelas = new javax.swing.JComboBox<>();
        bayangan3 = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        fbayar = new javax.swing.JTextField();
        sdewasa = new javax.swing.JSpinner();
        sanak = new javax.swing.JSpinner();
        fid = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        fnama = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        bayangan2 = new javax.swing.JTextField();
        kota = new javax.swing.JComboBox<>();
        ltotal = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        lkembali = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        hdewasa = new javax.swing.JLabel();
        hanak = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        bayangan4 = new javax.swing.JSpinner();
        tanggal = new com.toedter.calendar.JDateChooser();
        jLabel5 = new javax.swing.JLabel();
        film = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();

        jTextField5.setText("jTextField1");

        jTextField4.setText("jTextField1");

        jLabel8.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        jLabel8.setText("ID Pelanggan           :");

        jMenu3.setText("File");
        jMenuBar2.add(jMenu3);

        jMenu4.setText("Edit");
        jMenuBar2.add(jMenu4);

        jMenu5.setText("File");
        jMenuBar3.add(jMenu5);

        jMenu6.setText("Edit");
        jMenuBar3.add(jMenu6);

        jMenu7.setText("File");
        jMenuBar4.add(jMenu7);

        jMenu8.setText("Edit");
        jMenuBar4.add(jMenu8);

        jMenu9.setText("File");
        jMenuBar5.add(jMenu9);

        jMenu10.setText("Edit");
        jMenuBar5.add(jMenu10);

        jMenu11.setText("File");
        jMenuBar6.add(jMenu11);

        jMenu12.setText("Edit");
        jMenuBar6.add(jMenu12);

        jMenu13.setText("File");
        jMenuBar7.add(jMenu13);

        jMenu14.setText("Edit");
        jMenuBar7.add(jMenu14);

        jMenu15.setText("File");
        jMenuBar8.add(jMenu15);

        jMenu16.setText("Edit");
        jMenuBar8.add(jMenu16);

        jMenu17.setText("File");
        jMenuBar9.add(jMenu17);

        jMenu18.setText("Edit");
        jMenuBar9.add(jMenu18);

        jMenu19.setText("File");
        jMenuBar10.add(jMenu19);

        jMenu20.setText("Edit");
        jMenuBar10.add(jMenu20);

        button1.setLabel("button1");

        label1.setText("label1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel3.setBackground(new java.awt.Color(192, 129, 86));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        btnsimpan1.setBackground(new java.awt.Color(227, 223, 168));
        btnsimpan1.setFont(new java.awt.Font("Century", 1, 18)); // NOI18N
        btnsimpan1.setText("Simpan");
        btnsimpan1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnsimpan1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnsimpan1MouseClicked(evt);
            }
        });
        btnsimpan1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsimpan1simpan(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnsimpan1, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnsimpan1, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel3.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 460, -1, -1));

        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/icons8-batman-100.png"))); // NOI18N
        jPanel3.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 10, 110, 90));

        jLabel19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/icons8-film-reel-100.png"))); // NOI18N
        jPanel3.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 10, 100, 100));

        jPanel2.setBackground(new java.awt.Color(227, 223, 168));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel14.setFont(new java.awt.Font("YouYuan", 1, 18)); // NOI18N
        jLabel14.setText("Bayar       :");
        jPanel2.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 210, -1, 27));

        bayangan5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bayangan5ActionPerformed(evt);
            }
        });
        jPanel2.add(bayangan5, new org.netbeans.lib.awtextra.AbsoluteConstraints(13, 266, 103, 30));
        jPanel2.add(bayangan1, new org.netbeans.lib.awtextra.AbsoluteConstraints(134, 266, 103, 30));

        kelas.setFont(new java.awt.Font("Rockwell", 0, 14)); // NOI18N
        kelas.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " ", "VIP 1", "VIP 2", "Standard 1", "Standard 2", "Standard 3" }));
        kelas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kelasActionPerformed(evt);
            }
        });
        jPanel2.add(kelas, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 210, 220, 31));
        jPanel2.add(bayangan3, new org.netbeans.lib.awtextra.AbsoluteConstraints(384, 266, 103, 30));

        jLabel7.setFont(new java.awt.Font("YouYuan", 1, 18)); // NOI18N
        jLabel7.setText("Kelas                  :");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 210, 219, 30));

        fbayar.setBackground(new java.awt.Color(227, 243, 219));
        fbayar.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        fbayar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fbayarActionPerformed(evt);
            }
        });
        fbayar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                fbayarKeyPressed(evt);
            }
        });
        jPanel2.add(fbayar, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 210, 188, 30));

        sdewasa.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        sdewasa.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                sdewasaStateChanged(evt);
            }
        });
        jPanel2.add(sdewasa, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 70, -1, 30));

        sanak.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        sanak.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                sanakStateChanged(evt);
            }
        });
        jPanel2.add(sanak, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 120, -1, 30));

        fid.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        fid.setToolTipText("");
        fid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fidActionPerformed(evt);
            }
        });
        jPanel2.add(fid, new org.netbeans.lib.awtextra.AbsoluteConstraints(238, 21, 220, 31));

        jLabel15.setFont(new java.awt.Font("YouYuan", 1, 18)); // NOI18N
        jLabel15.setText("/Orang");
        jPanel2.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 120, -1, -1));

        fnama.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        fnama.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fnamaActionPerformed(evt);
            }
        });
        jPanel2.add(fnama, new org.netbeans.lib.awtextra.AbsoluteConstraints(238, 65, 220, 31));

        jLabel1.setFont(new java.awt.Font("YouYuan", 1, 18)); // NOI18N
        jLabel1.setText("ID Pelanggan           :");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(13, 22, 219, 31));

        jLabel17.setFont(new java.awt.Font("YouYuan", 1, 18)); // NOI18N
        jLabel17.setText("Rp. ");
        jPanel2.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 70, -1, -1));

        jLabel2.setFont(new java.awt.Font("YouYuan", 1, 18)); // NOI18N
        jLabel2.setText("Nama Pelanggan         :");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(13, 66, -1, 29));
        jPanel2.add(bayangan2, new org.netbeans.lib.awtextra.AbsoluteConstraints(263, 266, 103, 30));

        kota.setFont(new java.awt.Font("Rockwell", 0, 14)); // NOI18N
        kota.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "", "Balikpapan", "Berau", "Tarakan", "Banjarmasin", "Pontianak", "" }));
        kota.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kotaActionPerformed(evt);
            }
        });
        jPanel2.add(kota, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 160, 220, 31));

        ltotal.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        ltotal.setText("0 ");
        jPanel2.add(ltotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 170, 186, 20));

        jLabel3.setFont(new java.awt.Font("YouYuan", 1, 18)); // NOI18N
        jLabel3.setText("Film                   :");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(13, 114, 219, 32));
        jLabel3.getAccessibleContext().setAccessibleName("Alamat\n:");

        lkembali.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 18)); // NOI18N
        lkembali.setText("0 ");
        jPanel2.add(lkembali, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 260, 186, 20));

        jLabel4.setFont(new java.awt.Font("YouYuan", 1, 18)); // NOI18N
        jLabel4.setText("Kota                   :");
        jLabel4.setToolTipText("");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 160, 219, 27));

        jLabel20.setFont(new java.awt.Font("YouYuan", 1, 18)); // NOI18N
        jLabel20.setText("Rp. ");
        jPanel2.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 120, -1, -1));

        jLabel9.setFont(new java.awt.Font("YouYuan", 1, 18)); // NOI18N
        jLabel9.setText("Dewasa      :");
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 70, 120, 28));

        jLabel10.setFont(new java.awt.Font("YouYuan", 1, 18)); // NOI18N
        jLabel10.setText("Kembali     :");
        jPanel2.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 260, -1, -1));

        hdewasa.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 18)); // NOI18N
        hdewasa.setText("0 ");
        jPanel2.add(hdewasa, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 70, 88, 20));

        hanak.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        hanak.setText("0 ");
        jPanel2.add(hanak, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 120, 88, 20));

        jLabel11.setFont(new java.awt.Font("YouYuan", 1, 18)); // NOI18N
        jLabel11.setText("Anak-Anak   :");
        jPanel2.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 120, -1, 30));

        jLabel12.setFont(new java.awt.Font("YouYuan", 1, 18)); // NOI18N
        jLabel12.setText("Total       :");
        jPanel2.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 170, 121, 30));

        jLabel13.setFont(new java.awt.Font("YouYuan", 1, 18)); // NOI18N
        jLabel13.setText("/Orang");
        jPanel2.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 70, -1, -1));
        jPanel2.add(bayangan4, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 216, 56, 32));
        jPanel2.add(tanggal, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 20, 390, 31));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/icons8-short-film-100.png"))); // NOI18N
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 250, 100, 80));

        film.setFont(new java.awt.Font("Rockwell", 0, 14)); // NOI18N
        film.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "", "Rocky", "Grease", "Dazed and Confused", "Almost Famous" }));
        film.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                filmActionPerformed(evt);
            }
        });
        jPanel2.add(film, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 110, 220, 30));

        jPanel3.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, 970, 330));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/icons8-movie-projector-100.png"))); // NOI18N
        jPanel3.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 100, 100));

        jMenu1.setText("File");
        jMenu1.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N

        jMenuItem1.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        jMenuItem1.setText("Menu Admin");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        jMenuItem2.setText("Keluar");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem2);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Data Pelanggan");
        jMenu2.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        jMenu2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu2MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, 990, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, 536, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    
        private void autoid(){
       try{
            con = koneksi.getKoneksi();
            String sql = "SELECT COUNT(id) as kode FROM pelanggan";
            stm = con.createStatement();
            rs = stm.executeQuery(sql);
            while(rs.next()){
                String kode = rs.getString("kode");
                int a = Integer.parseInt(kode);
                int b = a+1;
                fid.setText("MR. "+b);
            }
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e);
        }
    }
    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        dispose();
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void jMenu2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu2MouseClicked
        new Pelanggan().setVisible(true);
        dispose();
    }//GEN-LAST:event_jMenu2MouseClicked

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        new admin().setVisible(true);
        dispose();
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void kotaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kotaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_kotaActionPerformed

    private void fnamaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fnamaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fnamaActionPerformed

    private void fidActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fidActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fidActionPerformed

    private void sanakStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_sanakStateChanged
        int a = Integer.parseInt(bayangan1.getText());
        int m = Integer.parseInt(hanak.getText());
        int b = (int) sanak.getValue();
        int c = b*m;
        int d = c+a;
        ltotal.setText("Rp. "+d);
        bayangan2.setText(""+d);
    }//GEN-LAST:event_sanakStateChanged

    private void sdewasaStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_sdewasaStateChanged
        int a = (int) sdewasa.getValue();
        int b = Integer.parseInt(hdewasa.getText());
        int c = a*b;
        ltotal.setText("Rp. "+c);
        bayangan1.setText(""+c);

    }//GEN-LAST:event_sdewasaStateChanged

    private void fbayarKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_fbayarKeyPressed
        if(evt.getKeyCode()==KeyEvent.VK_ENTER){
            try {
                if (Integer.parseInt(fbayar.getText()) > 0) {
                    if(sanak.getValue().equals(0)){
                        int a = Integer.parseInt(bayangan1.getText());
                        int b = Integer.parseInt(fbayar.getText());
                        int c = b-a;
                        lkembali.setText("Rp. "+c);
                    }else{
                        int a = Integer.parseInt(bayangan2.getText());
                        int b = Integer.parseInt(fbayar.getText());
                        int c = b-a;
                        lkembali.setText("Rp. "+c);
                    }
                } else {
                    JOptionPane.showMessageDialog(null,"Masukkan nominal yang benar");
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null,"Masukkan nominal yang benar");
            }
        }        // TODO add your handling code here:
    }//GEN-LAST:event_fbayarKeyPressed

    private void fbayarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fbayarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fbayarActionPerformed

    private void kelasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kelasActionPerformed

        if(kelas.getSelectedItem().equals("VIP 1")){
            bayangan5.setText("vip1");
        }else if(kelas.getSelectedItem().equals("VIP 2")){
            bayangan5.setText("vip2");
        }else if(kelas.getSelectedItem().equals("Standard 1")){
            bayangan5.setText("standard1");
        }else if(kelas.getSelectedItem().equals("Standard 2")){
            bayangan5.setText("standard2");
        }else if(kelas.getSelectedItem().equals("Standard 3")){
            bayangan5.setText("standard3");
        }

        con = koneksi.getKoneksi();

        if((kelas.getSelectedItem().equals("VIP 1")) || (kelas.getSelectedItem().equals("VIP 2"))){
            try{
                stm = con.createStatement();

                String sql1 = "SELECT * FROM harga WHERE id='111'";
                rs = stm.executeQuery(sql1);
                while(rs.next()){
                    hdewasa.setText(rs.getString("harga"));
                }

                String sql2 = "SELECT * FROM harga WHERE id='222'";
                rs = stm.executeQuery(sql2);
                while(rs.next()){
                    hanak.setText(rs.getString("harga"));
                }
            }catch(SQLException e){
                JOptionPane.showMessageDialog(null,e);
            }
        }else if((kelas.getSelectedItem().equals("Standard 1")) || (kelas.getSelectedItem().equals("Standard 2")) || (kelas.getSelectedItem().equals("Standard 3"))){
            try{
                stm = con.createStatement();

                String sql1 = "SELECT * FROM harga WHERE id='333'";
                rs = stm.executeQuery(sql1);
                while(rs.next()){
                    hdewasa.setText(rs.getString("harga"));
                }

                String sql2 = "SELECT * FROM harga WHERE id='444'";
                rs = stm.executeQuery(sql2);
                while(rs.next()){
                    hanak.setText(rs.getString("harga"));
                }
            }catch(SQLException e){
                JOptionPane.showMessageDialog(null,e);
            }
        }
    }//GEN-LAST:event_kelasActionPerformed

    private void bayangan5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bayangan5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_bayangan5ActionPerformed

    private void btnsimpan1simpan(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsimpan1simpan

    }//GEN-LAST:event_btnsimpan1simpan

    private void btnsimpan1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnsimpan1MouseClicked
        try{
            con = koneksi.getKoneksi();
            String sql = "INSERT INTO pelanggan VALUES('"
                    +fid.getText()+"','"
                    +fnama.getText()+"','"
                    +film.getSelectedItem()+"','"
                    +kota.getSelectedItem()+"','"
                    +kelas.getSelectedItem()+"','"
                    +tanggal.getDate()+"','"
                    +sdewasa.getValue()+"','"
                    +sanak.getValue()+"','"
                    +ltotal.getText()+"')";
            stm = con.createStatement();
            stm.execute(sql);
            new Pelanggan().setVisible(true);
            this.dispose();
            //            index.oke();

        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e);
        }
    }//GEN-LAST:event_btnsimpan1MouseClicked

    private void filmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_filmActionPerformed
        
        if(film.getSelectedItem().equals("Rocky")){
        bayangan4.setValue(1);
        film.setSelectedIndex(1);
       }else if(film.getSelectedItem().equals("Grease")){
       bayangan4.setValue(2);
       film.setSelectedIndex(2);
       }
       else if(film.getSelectedItem().equals("Dazed and Confused")){
       bayangan4.setValue(3);
       film.setSelectedIndex(3);
       }
       
       if(film.getSelectedItem().equals("Rocky") && kota.getSelectedItem().equals("Balikpapan")){
         
        }else if(film.getSelectedItem().equals("Rocky") && kota.getSelectedItem().equals("Berau")){

        }else if(film.getSelectedItem().equals("Rocky") && kota.getSelectedItem().equals("Tarakan")){
  
        }else if(film.getSelectedItem().equals("Rocky") && kota.getSelectedItem().equals("Banjarmasin")){
 
        }else if(film.getSelectedItem().equals("Rocky") && kota.getSelectedItem().equals("Pontianak")){

            
            //Grease
        }else if(film.getSelectedItem().equals("Grease") && kota.getSelectedItem().equals("Balikpapan")){
    
        }else if(film.getSelectedItem().equals("Grease") && kota.getSelectedItem().equals("Berau")){

        }else if(film.getSelectedItem().equals("Grease") && kota.getSelectedItem().equals("Tarakan")){

        }else if(film.getSelectedItem().equals("Grease") && kota.getSelectedItem().equals("Banjarmasin")){

        }else if(film.getSelectedItem().equals("Grease") && kota.getSelectedItem().equals("Pontianak")){

            
            //Dazed and Confused
        }else if(film.getSelectedItem().equals("Dazed and Confused") && kota.getSelectedItem().equals("Balikpapan")){

        }else if(film.getSelectedItem().equals("Dazed and Confused") && kota.getSelectedItem().equals("Berau")){

        }else if(film.getSelectedItem().equals("Dazed and Confused") && kota.getSelectedItem().equals("Tarakan")){

        }else if(film.getSelectedItem().equals("Dazed and Confused") && kota.getSelectedItem().equals("Banjarmasin")){

        }else if(film.getSelectedItem().equals("Dazed and Confused") && kota.getSelectedItem().equals("Pontianak")){

        }
    }//GEN-LAST:event_filmActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Utama.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Utama.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Utama.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Utama.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Utama().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField bayangan1;
    private javax.swing.JTextField bayangan2;
    private javax.swing.JTextField bayangan3;
    private javax.swing.JSpinner bayangan4;
    private javax.swing.JTextField bayangan5;
    private javax.swing.JButton btnsimpan1;
    private java.awt.Button button1;
    private javax.swing.JTextField fbayar;
    private javax.swing.JTextField fid;
    private javax.swing.JComboBox<String> film;
    private javax.swing.JTextField fnama;
    private javax.swing.JLabel hanak;
    private javax.swing.JLabel hdewasa;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu10;
    private javax.swing.JMenu jMenu11;
    private javax.swing.JMenu jMenu12;
    private javax.swing.JMenu jMenu13;
    private javax.swing.JMenu jMenu14;
    private javax.swing.JMenu jMenu15;
    private javax.swing.JMenu jMenu16;
    private javax.swing.JMenu jMenu17;
    private javax.swing.JMenu jMenu18;
    private javax.swing.JMenu jMenu19;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu20;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenu jMenu6;
    private javax.swing.JMenu jMenu7;
    private javax.swing.JMenu jMenu8;
    private javax.swing.JMenu jMenu9;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuBar jMenuBar10;
    private javax.swing.JMenuBar jMenuBar2;
    private javax.swing.JMenuBar jMenuBar3;
    private javax.swing.JMenuBar jMenuBar4;
    private javax.swing.JMenuBar jMenuBar5;
    private javax.swing.JMenuBar jMenuBar6;
    private javax.swing.JMenuBar jMenuBar7;
    private javax.swing.JMenuBar jMenuBar8;
    private javax.swing.JMenuBar jMenuBar9;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JComboBox<String> kelas;
    private javax.swing.JComboBox<String> kota;
    private java.awt.Label label1;
    private javax.swing.JLabel lkembali;
    private javax.swing.JLabel ltotal;
    private javax.swing.JSpinner sanak;
    private javax.swing.JSpinner sdewasa;
    private com.toedter.calendar.JDateChooser tanggal;
    // End of variables declaration//GEN-END:variables
}
